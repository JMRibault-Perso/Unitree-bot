# unitree_slam_example

### Build examples
```bash
#1.Install unitree_sdk2
Please refer to the details: https://github.com/unitreerobotics/unitree_sdk2

#2.Build key demo examples
mkdir build				
cd build
cmake ..
make

#3.Run
./keyDemo eth0     #eth0:The name of the network card with network segment 123
```
